import PlaygroundSupport

var newMood = Mood()
var spot = spotView().environmentObject(newMood)

PlaygroundPage.current.setLiveView(spot)

/*:
 # SPOT THE EMOTION
 
 This first tool is designed to let kids play and experiment with emotions in a tactile and fun way. Here, animations and sound effects are used to maintain kids atention while they explore and learn how to understand, identify and express their emotions.
 
 */

//: You can play with adding, removing or editing emotions following the guides below and see that reflected in the screen

newMood.addEmotion(emoji: "😄", name: "Happy")
newMood.addEmotion(emoji: "😞", name: "Sad")
newMood.addEmotion(emoji: "😡", name: "Angry")
newMood.addEmotion(emoji: "😱", name: "Scared")
newMood.addEmotion(emoji: "😲", name: "Surprised")


//: When you are ready you can follow me to the [Final Screen](@next)


