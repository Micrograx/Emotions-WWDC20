

/*:
 # WELCOME
 ### An interactive tool/game.
 
 
 Welcome to Emotions, this tool is designed for teachers and parents of kids with difficulties understanding and expressing emotions.
 
 
 
This tool was developed to help kids in their learning path by encouraging them to play with emotions, while trying to identify, understand and convey them.
 
 
 Join me through this demo of Emotions by going to the
 [First Screen](@next)
 
 */

