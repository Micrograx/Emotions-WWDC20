import PlaygroundSupport

var newMood = Mood()
var newScenario = Scenario()

var feel = mainFeelView().environmentObject(newMood).environmentObject(newScenario)
PlaygroundPage.current.setLiveView(feel)


/*:
 # HOW DO YOU FEEL
 
 This second tool, called "How do you feel when you..." is designed to give teachers and parents a way to understand **the way the kids feel** in different situations.
 
 Kids are presented with a situation and are expected to select the emotion they most associate with that situation from the right panel.
 
 */


/*:
 You can play with adding or removing emotions following the guides below and see that reflected in the game
 */
newMood.addEmotion(emoji: "😄", name: "Happy")
newMood.addEmotion(emoji: "😞", name: "Sad")
newMood.addEmotion(emoji: "😡", name: "Angry")


/*:
 Also, you can add or remove situations following the guides below and see that reflected in the game
 
 *Notice that if you add a lot of situations, you may need to expand the history screen to show them all correctly.
 */

newScenario.addSituation(emoji: "📚", name: "Study")
newScenario.addSituation(emoji: "🏃‍♂️", name: "Run")
newScenario.addSituation(emoji: "🎼", name: "Listen to Music")
newScenario.addSituation(emoji: "🏫", name: "Go to School")
newScenario.addSituation(emoji: "🎉", name: "Party")
newScenario.addSituation(emoji: "🗣", name: "Are Screamed At")
newScenario.addSituation(emoji: "🍎", name: "Eat Fruit")
newScenario.addSituation(emoji: "🧎🏽", name: "Are Alone")
newScenario.addSituation(emoji: "🎥", name: "Watch Movies")

newScenario.updateCurrent()

/*:
 Thanks for playing along with **Emotions**, I hope you liked the project.
 I will be porting this to a full app in the near future, so heads up for that if you are interested.
 */
