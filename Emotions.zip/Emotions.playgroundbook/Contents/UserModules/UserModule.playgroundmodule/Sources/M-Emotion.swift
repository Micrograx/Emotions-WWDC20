import SwiftUI

private let voice = Speak()

public class Mood: Identifiable, ObservableObject{
    public var id = UUID()
    @Published var cant = 0.0
    @Published var emotionList: [Emotion] = []
    @Published var currentEmotion: Emotion? = nil
    
    public init(){}
    
    // Add the given Emotion to the list
    public func addEmotion(emoji: String, name: String){
        self.cant += 1
        DispatchQueue.main.asyncAfter(deadline: .now() + (0.3 * self.cant)){
            withAnimation(.interpolatingSpring(stiffness: 50, damping: 5.0)){
                self.emotionList.append(Emotion(emoji: emoji, name: name))
                playSound(sound: "plop1", type: "m4a")
            }
        }
        
    }
    
    // Updates the current selected Emotion to higlight it
    public func updateCurrent(_ emotion: Emotion, onCompletion: @escaping () -> Void){
        if (self.currentEmotion == nil){
            voice.say(emotion.name)
            withAnimation(.interpolatingSpring(stiffness: 50, damping: 7.0)){
                self.currentEmotion = emotion
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.interpolatingSpring(stiffness: 50, damping: 7.0)){
                    self.currentEmotion = nil
                }
                onCompletion()
            }
        }
    }
}

// Basic Emotion Model
public struct Emotion: Identifiable, Equatable{
    public var id = UUID()
    var emoji: String
    var name: String
}


