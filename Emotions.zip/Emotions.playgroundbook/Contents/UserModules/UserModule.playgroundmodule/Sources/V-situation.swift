import SwiftUI

// Present all Situations on a ZStack to play the animation of them falling and getting up
public struct situationStack: View{
    @EnvironmentObject var scenario: Scenario
    
    public var body: some View{
        ZStack{
            ForEach (scenario.situationList) {situation in
                situationView(situation)
                    .rotationEffect(.degrees(self.scenario.currentSituation == situation ? 0 : 180), anchor: .bottom)
                    .opacity(self.scenario.currentSituation == situation ? 1 : 0)
                    .animation(.easeInOut(duration: 0.6))
            }
        }
    }
}

// The basic Situation View presented in the How do You Feel View
public struct situationView: View{
    public var situation: Situation
    
    init(_ sit: Situation){
        self.situation = sit
    }
    
    public var body: some View{
        GeometryReader {geometry in
            ZStack{
                VStack{
                    Spacer()
                    Text(self.situation.emoji)
                        .font(.system(size: min(geometry.size.width / 2, geometry.size.height / 2)))
                    Spacer()
                    
                    Text(self.situation.name)
                        .font(.system(size: 60, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.001)
                        .padding(10)
                        .foregroundColor(Color.black)
                    
                    Spacer()
                }
            }
        }.frame(maxWidth: 300, maxHeight: 500)
            .background(myColors.grey)
            .cornerRadius(50.0)
            
    }
}

// Detailed Situation View showing the emotions selected while playing
public struct detailedSituationView: View{
    public var situation: Situation
    
    init(_ situation: Situation?){
        if let sit = situation{
            self.situation = sit
        }else{
            self.situation = Situation(emoji: "", name: "")
        }
    }
    
    public var body: some View{
        VStack{
            HStack{
                Text(self.situation.emoji)
                    .font(.system(size: 50))
                    .padding(10)
                
                        
                Text(self.situation.name)
                    .font(.system(.title, design: .rounded))
                    // If the name of the situation is just a word, resize it down, if it is a phrase let it span 2 lines
                    .lineLimit((self.situation.name.components(separatedBy: " ")).count == 1 ? 1 : 2) 
                    .minimumScaleFactor(0.001) // Lets resize the text as needed to fit in the parent view
                    .foregroundColor(Color.black)
                .padding(10)
                
                Spacer()
            }
            Spacer()
                    
            emotionList(sit: self.situation)
                .padding(30)
        }
        .frame(maxWidth: 300, maxHeight: 200)
            .background(myColors.grey)
            .cornerRadius(50.0)
        .scaleEffect(0.8)
    }
}

// The emotion list to show the ammount selected while playing
private struct emotionList: View{
    @EnvironmentObject var mood: Mood
    @EnvironmentObject var scenario: Scenario
    var sit: Situation
    
    public var body: some View{
        HStack{
            ForEach (mood.emotionList) {emotion in
                if (self.scenario.getCount(situation: self.sit, emotion: emotion) != nil){
                    VStack{
                        Text(emotion.emoji)
                            .font(.system(size: 40))
                        
                        Text(" \(self.scenario.getCount(situation: self.sit, emotion: emotion)!) ")
                            .foregroundColor(myColors.darkGreen)
                    }
                }
                
            }
        }
    }
}


