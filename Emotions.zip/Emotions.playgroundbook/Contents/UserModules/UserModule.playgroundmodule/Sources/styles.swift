import SwiftUI

public struct emojiButtonStyle: ButtonStyle{
    var emoji: String
    var current: Emotion?
//      
    public func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .padding(10)
            .scaleEffect(configuration.isPressed ? 0.7 : 1.0)
            .animation(.interpolatingSpring(stiffness: 50, damping: 7))
            .scaleEffect((self.current != nil && self.current?.emoji == self.emoji) ? 2 : 1)
            .scaleEffect((self.current != nil && self.current?.emoji != self.emoji) ? 0 : 1)
            .transition(.scale)
    }
}

public class myColors{
    static let darkGreen  = Color.init(red: 31/255, green: 64/255, blue: 55/255)
    static let lightGreen = Color.init(red: 153/255, green: 242/255, blue: 200/255)
    static let grey = Color.init(red: 170/255, green: 180/255, blue: 180/255)
}


/* This code to build grids was taken from the Hacking With Swift webpage tutorial
 https://www.hackingwithswift.com/quick-start/swiftui/how-to-position-views-in-a-grid
 This is used in the History View to display all situations in a compact way.
 */ 
struct GridStack<Content: View>: View {
    let rows: Int
    let columns: Int
    let content: (Int, Int) -> Content
    
    var body: some View {
        VStack() {
            ForEach(0 ..< rows, id: \.self) { row in
                HStack{
                    ForEach(0 ..< self.columns, id: \.self) { column in
                        self.content(row, column)
                    }
                }
            }
        }
    }
    
    init(rows: Int, columns: Int, @ViewBuilder content: @escaping (Int, Int) -> Content) {
        self.rows = rows
        self.columns = columns
        self.content = content
    }
}
