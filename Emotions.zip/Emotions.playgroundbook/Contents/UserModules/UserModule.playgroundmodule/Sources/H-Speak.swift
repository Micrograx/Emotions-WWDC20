import AVFoundation

// Helper Function to use AVSpeechSynteshis
public class Speak {
    
    let voices = AVSpeechSynthesisVoice.speechVoices()
    let voiceSynth = AVSpeechSynthesizer()
    var voiceToUse: AVSpeechSynthesisVoice?
    var backupVoice: AVSpeechSynthesisVoice?
    
    init(){
        // Search for an "enhanced" voice in english installed in the system
        for voice in voices {
            if voice.language == "en-US"{
                if voice.quality == AVSpeechSynthesisVoiceQuality.enhanced {
                    voiceToUse = voice
                    print("Enhanced")
                }else{
                    // If none is found, the last english voice found will be used as a backup
                    backupVoice = voice
                    print("Backup")
                }
            }
        }    
    }
    
    func say(_ phrase: String){
        // Function that actually does the speaking
        let utterance = AVSpeechUtterance(string: phrase)
        utterance.voice = voiceToUse != nil ? voiceToUse : backupVoice
        utterance.rate = 0.3
        voiceSynth.speak(utterance) 
    }
}


