import SwiftUI

public class Scenario: Identifiable, ObservableObject{
    public var id = UUID()
    @Published var situationList: [Situation] = []
    @Published var currentSituation: Situation? = nil
    @Published var history = [String:[String:Int]]()
    private var randomSituations: [Situation] = []
    private let voice = Speak()
    
    public init(){}
    
    // Adds the given Situation to the list and prepares the history dict
    public func addSituation(emoji: String, name: String){
        self.situationList.append(Situation(emoji: emoji, name: name))
        self.history[name] = [:]
        self.randomSituations = self.situationList.shuffled()
    }
    
    // Updates the Current Emotion from the shuffled array
    // This assures that every situation is presented before repeating
    public func updateCurrent(){
        self.currentSituation = self.randomSituations.last
        if (self.randomSituations.count == 1){
            self.randomSituations = self.situationList.shuffled()
        }else{
            self.randomSituations.removeLast()
        }
    }
    
    // Adds the emotion selected to the history dict
    // Or sum one to the value if it alreafy exist
    public func addHistory(_ emotion: String){
        let cur = self.currentSituation!.name
        if (self.history[cur]?[emotion] == nil){
            self.history[cur]?[emotion] = 1
        }else{
            self.history[cur]?[emotion]! += 1
        }
    }
    // Funtion to get the history count for a specified situation and emotion
    public func getCount(situation: Situation, emotion: Emotion) -> Int? {
        return self.history[situation.name]?[emotion.name]
    }
    
}

// Basic Situation Model
public struct Situation: Identifiable, Equatable{
    public var id = UUID()
    var emoji: String
    var name: String
}


