import SwiftUI

// Main view to show the history of selected Emotions for all Situations
public struct historyView: View{
    @EnvironmentObject var mood: Mood
    @EnvironmentObject var scenario: Scenario
    
    var row: Int = 3
    var col: Int = 3
    
    public init(){}
    
    public var body: some View{
        ZStack{
            Rectangle()
                .background(Color.white)
                .opacity(0.4)
                .cornerRadius(50.0)
            
            VStack{
                Text("History")
                    .font(.system(size: 70, design: .rounded))
                    .foregroundColor(Color.black)
                    .padding(30)
                Spacer()
                
                GridStack(rows: self.row, columns: self.col) { row, col in
                    if (row * self.col + col < self.scenario.situationList.count){
                        detailedSituationView(self.scenario.situationList[row * self.col + col])
                    }
                }
                
                Spacer()
                }
        }.padding(30)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(LinearGradient(gradient: Gradient(colors: [myColors.lightGreen, myColors.darkGreen]), startPoint: .topLeading, endPoint: .bottomTrailing))
    }
}


