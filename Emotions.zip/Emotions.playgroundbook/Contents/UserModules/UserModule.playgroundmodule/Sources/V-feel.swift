
import SwiftUI

private let voice = Speak()

// Main feel View that contains the tab bar
public struct mainFeelView: View{
    public init(){}
    
    public var body: some View{
        TabView{
            feelView()
            .tabItem{
                Image(systemName: "smiley")
                Text("How do you Feel When")
            }
            
            historyView()
                .tabItem{
                    Image(systemName: "clock")
                    Text("History")
            }
        }
    }
}

// How do You Feel When You... View
public struct feelView: View {
    @EnvironmentObject var mood: Mood
    @EnvironmentObject var scenario: Scenario
    @State private var showExplanation: Bool = false
    
    public init(){
        voice.say("How do You Feel When You?")
    }
    
    public var body: some View {
        ZStack{
            Rectangle()
                .background(Color.white)
                .opacity(0.4)
                .cornerRadius(50.0)
            
            VStack{
                Spacer()
                Text("How do You Feel When You...")
                    .font(.system(size:65, design: .rounded))
                    .foregroundColor(Color.black)
                    .padding(10)
                HStack{
                    
                    situationStack()
                    
                    Spacer()
                        VStack{
                        
                            Spacer()
                            
                            emotionList()
                            
                            Spacer()
                            
                            if self.mood.currentEmotion != nil{
                                Text(self.mood.currentEmotion == nil ? "" : self.mood.currentEmotion!.name)
                                    .frame(minWidth: 100, minHeight: 200)
                                    .animation(nil)
                                    .font(.system(size: 60))
                                    .scaleEffect(self.mood.currentEmotion != nil ? 1 : 0)
                                    .foregroundColor(Color.black)
                            }
                        
                    }
                    .padding(20)
                    .frame(minWidth: 100, minHeight: 500)
                    
                    
                }.padding(30)
            }
        }
        .padding(30)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LinearGradient(gradient: Gradient(colors: [myColors.lightGreen, myColors.darkGreen]), startPoint: .topLeading, endPoint: .bottomTrailing))
    }
    
}
    

// Present all the Emotion Buttons following the emojiButtonStyle
private struct emotionList: View{
    @EnvironmentObject var mood: Mood
    @EnvironmentObject var scenario: Scenario
    
    public var body: some View{
        ForEach (mood.emotionList) {emotion in
            if (emotion.name == self.mood.currentEmotion?.name || self.mood.currentEmotion == nil){
                Button(action:{
                    // When selected, update the current Emotion and Situation
                    self.mood.updateCurrent(emotion){
                        self.scenario.updateCurrent()
                        voice.say(self.scenario.currentSituation!.name)
                    } 
                    self.scenario.addHistory(emotion.name)
                    playSound(sound: "plop1", type: "m4a")
                }) {
                    Text(emotion.emoji)
                        .font(.system(size: 90))
                }
                .buttonStyle(emojiButtonStyle(emoji: emotion.emoji, current: self.mood.currentEmotion))
            }
        }
    }
}






