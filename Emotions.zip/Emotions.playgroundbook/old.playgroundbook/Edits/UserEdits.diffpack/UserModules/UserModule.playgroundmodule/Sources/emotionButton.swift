
import SwiftUI
import AVFoundation

public struct emojiButtonStyle: ButtonStyle{
    var emoji: String
    var current: Emotion?
    
    public func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .padding(10)
            .scaleEffect(configuration.isPressed ? 0.7 : 1.0)
            .animation(.interpolatingSpring(stiffness: 50, damping: 7))
            .scaleEffect((self.current != nil && self.current?.emoji == self.emoji) ? 2 : 1)
            .scaleEffect((self.current != nil && self.current?.emoji != self.emoji) ? 0 : 1)
    }
}
