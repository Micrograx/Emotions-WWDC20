
import Foundation
import SwiftUI
import AVFoundation

private let lightGreen = Color.init(red: 31/255, green: 64/255, blue: 55/255)
private let darkGreen = Color.init(red: 153/255, green: 242/255, blue: 200/255)

let voice = Speak()

public struct spotView: View {
    @EnvironmentObject var mood: Mood
    
    public init(){
        voice.say("Spot The Emotion")
    }
    
    public var body: some View {
        ZStack{
            Rectangle()
                .background(Color.white)
                .opacity(0.4)
                .cornerRadius(50.0)
                .padding(30)
            VStack{
                Spacer()
                Text("Spot The Emotion")
                    .font(.system(size:100, design: .rounded))
                    .foregroundColor(Color.black)
                
                Spacer()
                
                Text(mood.currentEmotion == nil ? "" : mood.currentEmotion!.name)
                    .frame(minWidth: 100, minHeight: 200)
                    .animation(nil)
                    .font(.system(size: 150))
                    .scaleEffect(mood.currentEmotion != nil ? 1 : 0)
                    .foregroundColor(Color.black)
                
                Spacer()
                
                HStack{
                    emotionList()
                }
                
                Spacer()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LinearGradient(gradient: Gradient(colors: [lightGreen, darkGreen]), startPoint: .topLeading, endPoint: .bottomTrailing))
    }
}


private struct emotionList: View{
    @EnvironmentObject var mood: Mood
    
    public var body: some View{
        ForEach (mood.emotionList) {emotion in
            if (emotion.name == self.mood.currentEmotion?.name || self.mood.currentEmotion == nil){
                Button(action: {
                    self.mood.updateCurrent(emotion){}
                }) {
                    Text(emotion.emoji)
                        .font(.system(size: 90))
                }
                .buttonStyle(emojiButtonStyle(emoji: emotion.emoji, current: self.mood.currentEmotion))
            }
        }
    }
}
