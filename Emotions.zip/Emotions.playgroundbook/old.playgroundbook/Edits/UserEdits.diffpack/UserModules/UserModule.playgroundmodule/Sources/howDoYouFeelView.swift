
import SwiftUI
import AVFoundation

private let darkGreen  = Color.init(red: 31/255, green: 64/255, blue: 55/255)
private let lightGreen = Color.init(red: 153/255, green: 242/255, blue: 200/255)

public struct feelView: View {
    @EnvironmentObject var mood: Mood
    @EnvironmentObject var scenario: Scenario
    
    public init(){
        voice.say("How do You Feel?")
    }
    
    public var body: some View {
        ZStack{
            Rectangle()
                .background(Color.white)
                .opacity(0.4)
                .cornerRadius(50.0)
                
            VStack{
                Spacer()
                Text("How do You Feel?")
                    .font(.system(size:100, design: .rounded))
                    .foregroundColor(Color.black)
                    .padding(30)
                
                HStack{
                    
                        situationView(self.scenario.currentSituation)
                    
                    Spacer()
                    
                    VStack{
                        Spacer()
                        
                        emotionList()
                        
                        Spacer()
                        
                        if mood.currentEmotion != nil{
                            Text(mood.currentEmotion!.name)
                                .frame(minWidth: 100, minHeight: 200)
                                .animation(nil)
                                .font(.system(size: 60))
                                .scaleEffect(mood.currentEmotion != nil ? 1 : 0)
                                .foregroundColor(Color.black)
                        }
                        
                        
                        Spacer()
                    }
                    .padding(20)
                    .frame(minWidth: 100, minHeight: 500)
                    
                }
                .padding(30)
            }
        }
        .padding(30)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LinearGradient(gradient: Gradient(colors: [lightGreen, darkGreen]), startPoint: .topLeading, endPoint: .bottomTrailing))
        
    }
    
}

private struct emotionList: View{
    @EnvironmentObject var mood: Mood
    @EnvironmentObject var scenario: Scenario
    
    public var body: some View{
        ForEach (mood.emotionList) {emotion in
            if (emotion.name == self.mood.currentEmotion?.name || self.mood.currentEmotion == nil){
                Button(action:{
                    self.mood.updateCurrent(emotion) {self.scenario.updateCurrent()}
                }) {
                    Text(emotion.emoji)
                        .font(.system(size: 90))
                }
                .buttonStyle(emojiButtonStyle(emoji: emotion.emoji, current: self.mood.currentEmotion))
            }
        }
    }
}



