import SwiftUI

public class Scenario: Identifiable, ObservableObject{
    public var id = UUID()
    @Published var situationList: [Situation] = []
    @Published var currentSituation: Situation? = Situation(emoji: "🏫", name: "School")
    
    public init(){}
    
    public func addSituation(emoji: String, name: String){
        self.situationList.append(Situation(emoji: emoji, name: name))
    }
    
    public func updateCurrent(){
        var temp: Situation?
        repeat {
            temp = self.situationList.randomElement()
        } while (temp == self.currentSituation)
        self.currentSituation = temp
    }
}

public struct Situation: Identifiable, Equatable{
    public var id = UUID()
    var emoji: String
    var name: String
}
