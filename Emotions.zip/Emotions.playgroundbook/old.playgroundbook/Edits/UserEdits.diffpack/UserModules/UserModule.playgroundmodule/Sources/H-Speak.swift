import AVFoundation

class Speak {
    
    let voices = AVSpeechSynthesisVoice.speechVoices()
    let voiceSynth = AVSpeechSynthesizer()
    var voiceToUse: AVSpeechSynthesisVoice?
    var backupVoice: AVSpeechSynthesisVoice?
    
    init(){
        for voice in voices {
            if voice.language == "en-US"{
                if voice.quality == AVSpeechSynthesisVoiceQuality.enhanced {
                    voiceToUse = voice
                    print("Enhanced")
                }else{
                    backupVoice = voice
                    print("Backup")
                }
                
            }
        }    
    }
    
    func say(_ phrase: String){
        let utterance = AVSpeechUtterance(string: phrase)
        utterance.voice = voiceToUse != nil ? voiceToUse : backupVoice
        utterance.rate = 0.3
        
        voiceSynth.speak(utterance) 
    }
}
