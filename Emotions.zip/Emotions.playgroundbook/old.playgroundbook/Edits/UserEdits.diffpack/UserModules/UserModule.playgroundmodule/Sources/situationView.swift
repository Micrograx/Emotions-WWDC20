import SwiftUI

public struct situationView: View{
    public var situation: Situation
    
    init(_ situation: Situation?){
        if let sit = situation{
            self.situation = sit
        }else{
            self.situation = Situation(emoji: "", name: "")
        }
    }
    
    public var body: some View{
        ZStack{
            if (self.situation != nil){
                Rectangle()
                    .background(Color.black)
                    .opacity(0.4)
                    .cornerRadius(50.0)
                
                VStack{
                    Spacer()
                    Text(self.situation.emoji)
                        .font(.system(size: 200))
                        .transition(.scale)
                    Spacer()
                    
                    Text(self.situation.name)
                        .frame(minWidth: 160, minHeight: 40)
                        .animation(nil)
                        .font(.system(size: 60, design: .rounded))
                        .foregroundColor(Color.black)
                    
                    Spacer()
                }
                
            }
        }.frame(maxWidth: 300)
    }
    
    
}
