
import SwiftUI


public struct welcomeView: View{
    
    public init(){}
    
    public var body: some View{
        
        VStack{
            Text("EMOTIONS")
            .font(.system(size: 100))
            Text("An interactive tool/game")
            .font(.system(size: 30))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
    
        
        
        
    }
}
